Desarrollo Point

Comision: 54140

Alumna: Martina Dichio

## comercializar departamentos del desarrollo point

## parte tecnica del proyecto

## futuras mejoras

## problemas conocidos 


